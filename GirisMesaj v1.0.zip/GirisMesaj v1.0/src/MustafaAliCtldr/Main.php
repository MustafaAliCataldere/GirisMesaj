<?php 

namespace MustafaAliCtldr;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;

class Main extends PluginBase implements Listener{
	
	public function onEnable(){
		$this->getLogger()->info("§7»Eklenti Aktif");
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
	}
	public function oyuncuGiris(PlayerJoinEvent $o){
		$giris = $o->getPlayer();
		$giris->sendMessage("§a»Sunucuya Hoşgeldin");
	}
}
?>